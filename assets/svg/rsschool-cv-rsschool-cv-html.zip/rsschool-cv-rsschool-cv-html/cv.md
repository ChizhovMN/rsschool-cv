# Maxim Chizhov
## Contact Info

* __Adress:__ Belarus, Homel
* __Phone:__ +375259361781
* __E-mail:__ chizhov98ip@gmail.com
* __Discord:__ prosperity#6772
* __Telegram:__ @mxm_chi

## Education and courses 
 
 1. Petroleum engineer
 2. JS https://learn.javascript.ru/ in progress
 3. JS, CSS, HTML video courses on Youtube
 
 ## About myself:
 
 I want to become a programmer.
 
 ## Code example:
 
 Make a program that filters a list of strings and returns a list with only your friends name in it.
If a name has exactly 4 letters in it, you can be sure that it has to be a friend of yours! Otherwise, you can be sure he's not...
Ex: Input = ["Ryan", "Kieran", "Jason", "Yous"], Output = ["Ryan", "Yous"]
```
function friend(friends){
  return friends.filter( a => a.length === 4)
};
```
 ## Languages:
 
 * Russian - Native
 * English - Beginner
